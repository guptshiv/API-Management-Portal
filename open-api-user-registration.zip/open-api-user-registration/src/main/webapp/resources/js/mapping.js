var subscribersTable, candidateTable;
var subscribedList, candidatesList;
var apiId;
var id;
$(document).ready(function() {
	getData();
} );
var getData=function(){
	apiId = $("#apiId").val();
	$.get("/admin/"+apiId+"/maphelp",function(result){  
		var x =JSON.parse(result);
		candidatesList = JSON.parse(x["str1"]);
		subscribedList = JSON.parse(x["str2"]);
		fillData();
	  });

}
var fillData= function(){
	var tablecontent = "";
	//console.log(candidatesList);
	for(var i=0;i<candidatesList.length;++i){
		tablecontent+="<tr>";
		tablecontent+="<td>"+(i+1)+"</td>";
		tablecontent+="<td>"+candidatesList[i]['id']+"</td>";
		tablecontent+="<td>"+candidatesList[i]['name']+"</td>";
		tablecontent+="<td>"+candidatesList[i]['email']+"</td>";
		tablecontent+="<td>"+"<button class=\"btn btn-success\" onClick=\"doMapping(this)\">Add</button>"+"</td>";
		tablecontent+="</tr>";
	}
	$('#content1').html(tablecontent);
	//console.log(subscribedList);
	tablecontent = "";
	for(var i=0;i<subscribedList.length;++i){
		tablecontent+="<tr>";
		tablecontent+="<td>"+(i+1)+"</td>";
		tablecontent+="<td>"+subscribedList[i]['id']+"</td>";
		tablecontent+="<td>"+subscribedList[i]['name']+"</td>";
		tablecontent+="<td>"+subscribedList[i]['email']+"</td>";
		tablecontent+="<td>"+subscribedList[i]['secretKey']+"</td>";
		tablecontent+="<td>"+subscribedList[i]['fromDate']+"</td>";
		tablecontent+="<td>"+subscribedList[i]['tillDate']+"</td>";
		tablecontent+="</tr>";
	}
	$('#content2').html(tablecontent);
	constructTable();
}

var constructTable = function(){
	subscribersTable = $("#table2").DataTable();
	candidateTable = $("#table1").DataTable();
}
var doMapping = function(sc){
	//var tableRow = candidateTable.row($(sc).parents('tr'));
	var number = candidateTable.row($(sc).parents('tr')).data();
	var clientId = number[1];
	var id = number[0]-1;
	console.log(id);
	$.get("/admin/"+apiId+"/mapsave/"+clientId,function(result){  
		var x =JSON.parse(result);
		candidatesList = JSON.parse(x["str1"]);
		subscribedList = JSON.parse(x["str2"]);
		fillData();
	  });
}
var back = function(){
	window.location.replace("/admin/apiedit");
	
}