var maintable;
$(document).ready(function() {
	maintable = $('#table_api').DataTable({
		"lengthChange": false,
	});
} );

$(function(){
	$("#access").change(function(){
		document.location.href = $(this).val();
	});
	$("#module").change(function(){
		maintable.search($("#module option:selected").val()).draw();
	});
	$("#all").click(function(){
		maintable.search("").draw();
	});
	$("#active").click(function(){
		maintable.search("active").draw();
	});
	$("#down").click(function(){
		maintable.search("maintenance").draw();
	});
	$("#blocked").click(function(){
		maintable.search("blocked").draw();
	});
});
