var maintable,id,responseList,apiList,subsCount,selectedApi="-1";
$(document).ready(function() {
	getData();
} );
$(function(){
	$("#module").change(function(){
		maintable.search($("#module option:selected").val()).draw();
	});
	$("#access").change(function(){
		document.location.href = $(this).val();
	});
	$("#all").click(function(){
		maintable.search("").draw();
	});
	$("#active").click(function(){
		maintable.search("active").draw();
	});
	$("#down").click(function(){
		maintable.search("maintenance").draw();
	});
	$("#blocked").click(function(){
		maintable.search("blocked").draw();
	});
});
var getData=function(){
	$.get("/admin/apiedit/datatable",function(result){
		//console.log("success");  
		var x =JSON.parse(result);
		apiList = JSON.parse(x["str1"]);
		responseList = JSON.parse(x["str2"]);
		subsCount = JSON.parse(x["str3"]);
		fillData();
	  });

}
var fillData= function(){
	var tablecontent = "";
	for(var i=0;i<apiList.length;++i){
		tablecontent+="<tr>";
		
		tablecontent+="<td><input type=\"radio\" name=\"det\" class=\"radio\" onClick=\"radioSelect(this)\"></td>";
		
		tablecontent+="<td>"+apiList[i]['apiId']+"</td>";
		
		tablecontent+="<td>";
		if(apiList[i]['activationFlag'] === "L" ){
			tablecontent+="<button type=\"button\" class=\"btn btn-light btn-xs\" onClick=\"lockunlock(this)\"><i class=\"fa fa-lock fa-2x\"></i></button>";
		}
		else if(apiList[i]['activationFlag'] === "U" ){
			tablecontent+="<button type=\"button\" class=\"btn btn-light btn-xs\" onClick=\"lockunlock(this)\"><i class=\"fa fa-unlock-alt fa-2x\"></i></button>";
		}
		else{
			tablecontent+="<button type=\"button\" class=\"btn btn-xs\"><i class=\"fa fa-circle fa-2x\" style=\"color:red\"></i></button>";
		}
		tablecontent+="<br/>"+apiList[i]['apiCode']+"</td>";
		
		tablecontent+="<td>"+apiList[i]['apiName']+"</td>";
		
		tablecontent+="<td><a href="+apiList[i]['endpointUrl']+"><i class=\"fa fa-file-pdf-o fa-2x\"></i></a></td>";
		tablecontent+="<td>";
		if(apiList[i]['serviceStatus'] === "U" ){
			tablecontent+="Maintenance <i class=\"fa fa-times-circle\" style=\"color:red\"></i>";
		}
		else if(apiList[i]['serviceStatus'] === "A" ){
			tablecontent+="Active <i class=\"fa fa-check-circle\" style=\"color:green\"></i>";
		}
		else{
			tablecontent+="Blocked <i class=\"fa fa-circle\" style=\"color:red\"></i>";
		}
		tablecontent+"</td>";
		
		tablecontent+="<td></td><td></td>";
		
		tablecontent+="<td><div type=\"button\" data-toggle=\"modal\" data-target=\"#response\" class=\"desc\"  onClick=\"showModal(this)\"><i class=\"fa fa-cogs fa-2x\"></i></div></td>";
		
		tablecontent+="<td>"+apiList[i]['moduleName']+"</td>";
		
		tablecontent+="<td>"+subsCount[apiList[i]['apiName']]+"</td>";
		
		tablecontent+="<td><a href=\"/admin/"+apiList[i]['apiId']+"/customer\"><i class=\"fa fa-info-circle fa-2x\"></i></a></td>";
		
		tablecontent+="</tr>";
	}
	$('#tablebody').html(tablecontent);
	constructTable();
}
var constructTable = function(){
	maintable = $('#table_api').DataTable({
		"lengthChange": false,
		"columnDefs": [
		    { "width": "20%", "targets": 5 }
		  ]
		//"destroy": true
	});
}
var radioSelect = function(sc){
	  var $box = $(sc);
	  var number = maintable.row($(sc).parents('tr')).data();
	  
	  if ($box.is(":checked")) {
	    var group = "input:radio[name='" + $box.attr("name") + "']";
	    $(group).prop("checked", false);
	    $box.prop("checked", true);
	    selectedApi = number[1];
	  } 
	  else {
	    $box.prop("checked", false);
	    selectedApi = "-1";
	  }
	  console.log(selectedApi);
}
var lockunlock = function(sc){
	var tableRow = maintable.row($(sc).parents('tr'));
	var number = maintable.row($(sc).parents('tr')).data();
	var activeC = parseInt($("#activeC").text());
	var downC = parseInt($("#downC").text());
	id = number[1]-1;
	var ele = $(sc).find('i');
	if(ele.hasClass("fa-lock")){
		ele.removeClass("fa-lock");
		ele.addClass("fa-unlock-alt");
		apiList[id]['activationFlag']="U";
		apiList[id]['serviceStatus']="A";
		number[2]="<button type=\"button\" class=\"btn btn-light btn-xs\" onClick=\"lockunlock(this)\"><i class=\"fa fa-unlock-alt fa-2x\"></i></button>";
		number[5]="Active <i class=\"fa fa-check-circle\" style=\"color:green\"></i>";
		$("#activeC").text(activeC+1);
		$("#downC").text(downC-1);
	}
	else{
		ele.addClass("fa-lock");
		ele.removeClass("fa-unlock-alt");
		apiList[id]['activationFlag']="L";
		apiList[id]['serviceStatus']="U";
		number[2]="<button type=\"button\" class=\"btn btn-light btn-xs\" onClick=\"lockunlock(this)\"><i class=\"fa fa-lock fa-2x\"></i></button>";
		number[5]="Maintenance <i class=\"fa fa-times-circle\" style=\"color:red\"></i>";
		$("#activeC").text(activeC-1);
		$("#downC").text(downC+1);
	}
	number[2]+="<br/>"+apiList[id]['apiCode']+"</td>";
	maintable.row( tableRow ).data(number).draw();
}
var showModal = function(ele){
	var number = maintable.row($(ele).parents('tr')).data();
	//console.log(number);
	id = number[1]-1;
	$("#modalCode").val(responseList[id]['responseCode']);
	$("#modalDesc").val(responseList[id]['responseDescription']);
}

var updateModal = function(){
	var id1 = id+1;
	var modalCode = $("#modalCode").val();
	var modalDescr = $("#modalDesc").val();
	modalJson={}
	modalJson['apiId']=id1;
	modalJson['responseCode']=modalCode;
	modalJson['responseDescription']=modalDescr;
	
	console.log(JSON.stringify(modalJson));
	
	$.ajax({
	      type: "POST",
	      contentType : 'application/json',
	      dataType : 'json',
	      url: "/admin/apiedit/modalUpdate",
	      data: JSON.stringify(modalJson),
	      success :function(result) {
	        //console.log("success");
	     },
	     error:function(result){
	    	 //console.log("haha");
	    	 console.log(result);
	    	 responseList[id]['responseCode']=modalCode;
	    	 responseList[id]['responseDescription']=modalDescr;
	     }
	  });
	
}
var submit = function(){
	console.log("Submiting")
	$.ajax({
	      type: "POST",
	      contentType : 'application/json',
	      dataType : 'json',
	      url: "/admin/apiedit/apiUpdate",
	      data: JSON.stringify(apiList),
	      success :function(result) {
	        console.log("success");
	     },
	     error:function(result){
	    	 console.log(result);
	     }
	  });
}

var mapping = function(){
	if(selectedApi==="-1"){
		alert("select an api");
	}else{
		window.location.replace("/admin/"+selectedApi+"/mapping");
	}
}

var setting = function(){
	if(selectedApi==="-1"){
		alert("select an api");
	}else{
		window.location.replace("/admin/"+selectedApi+"/setting")
	}
}

var adduser = function(){
	window.location.replace("/admin/adduser");
}

var statistics = function(){
	if(selectedApi==="-1"){
		alert("select an api");
	}else{
		window.location.replace("/admin/"+selectedApi+"/statistics")
	}
}