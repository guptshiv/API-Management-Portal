var threshold,config;
$(document).ready(function() {
	getData();
} );
var getData=function(){
	var id = $('#apiId').val();
	$.get("/admin/"+id+"/info",function(result){
		//console.log("success");  
		var x =JSON.parse(result);
		config = JSON.parse(x["config"]);
		threshold = JSON.parse(x["threshold"]);
		fillData();
	  });
}
var fillData = function(){
	var tablecontent="";
	for(var i=1;i<8;++i){
		//console.log(threshold[i]);
		tablecontent+="<form><tr>";
		tablecontent+="<td>"+i+"</td>";
		tablecontent+="<td>"+threshold[i]['weekday']+"</td>";
		if(threshold[i]['fromTime']!=null)
			tablecontent+="<td><input type=\'text\' class=\"time form-control\" onchange=\"fromTime(this)\" value=\""+threshold[i]['fromTime']+"\"/></td>";
		else
			tablecontent+="<td><input type=\'text\' class=\"time form-control\" onchange=\"fromTime(this)\"/></td>";
		if(threshold[i]['toTime']!=null)
			tablecontent+="<td><input type=\'text\' class=\"time form-control\" onchange=\"toTime(this)\"value=\""+threshold[i]['toTime']+"\"/></td>";
		else
			tablecontent+="<td><input type=\'text\' class=\"time form-control\" onchange=\"toTime(this)\"/></td>";
		tablecontent+="<td><input type=\"number\" min=\"0\" class=\"form-control\" onchange=\"hitSet(this)\" value=\""+threshold[i]['hitLimits']+"\"/></td>";
		tablecontent+="<td><input type=\"number\" min=\"0\" class=\"form-control\" onchange=\"volSet(this)\" value=\""+threshold[i]['volumeCap']+"\"/></td>";
		tablecontent+="</tr></form>";
	}
	$('#tableBody').html(tablecontent);
	$('#activation').datetimepicker();
	$('#termination').datetimepicker();
	$('.time').datetimepicker({
		pickDate: false
	});
	$('#activationDate').val(config['activationDate']);
	$('#terminationDate').val(config['terminationDate']);
	$("[name=limitType]").val([config['limitType']]);
	$("[name=onBreach]").val([config['onBreach']]);
	$("[name=threshold]").val([config['thresholdType']]);
	$("#allHit").val(threshold[0]['hitLimits']);
	$("#allVolume").val(threshold[0]['volumeCap']);	
}
$(document).ready(function(){
	$('input[name="limitType"]:radio' ).change(function(){
		config['limitType'] = $("input[type='radio'][name='limitType']:checked").val();
	});
	$('input[name="onBreach"]:radio' ).change(function(){
		config['onBreach'] = $("input[type='radio'][name='onBreach']:checked").val();
	});
	$('input[name="threshold"]:radio' ).change(function(){
		config['thresholdType'] = $("input[type='radio'][name='threshold']:checked").val();
	});
	
});

function fromTime(ele) {
	var $row = $(ele).closest("tr"),       
    $tds = $row.find("td:nth-child(1)");
	var id;
	$.each($tds, function() {              
		id = $(this).text();     
	});
	$tds = $row.find("td:nth-child(3)");
	var ft;
	$.each($tds, function() {              
		ft = $(this).find("input").val();     
	});
	console.log(id,ft);
	threshold[id]['fromTime'] = ft;
}
function toTime(ele) {
	var $row = $(ele).closest("tr"),       
    $tds = $row.find("td:nth-child(1)");
	var id;
	$.each($tds, function() {              
		id = $(this).text();     
	});
	$tds = $row.find("td:nth-child(4)");
	var tt;
	$.each($tds, function() {              
		tt = $(this).find("input").val();     
	});
	console.log(id,tt);
	threshold[id]['toTime'] = tt;
}
function hitSet(ele) {
	var $row = $(ele).closest("tr"),       
    $tds = $row.find("td:nth-child(1)");
	var id;
	$.each($tds, function() {              
		id = $(this).text();     
	});
	$tds = $row.find("td:nth-child(5)");
	var hit;
	$.each($tds, function() {              
		hit = $(this).find("input").val();     
	});
	console.log(id,hit);
	threshold[id]['hitLimits'] = hit;
}
function volSet(ele) {
	var $row = $(ele).closest("tr"),       
    $tds = $row.find("td:nth-child(1)");
	var id;
	$.each($tds, function() {              
		id = $(this).text();     
	});
	$tds = $row.find("td:nth-child(6)");
	var vol;
	$.each($tds, function() {              
		vol = $(this).find("input").val();     
	});
	console.log(id,vol);
	threshold[id]['volumeCap'] = vol;
}
var submit = function(){
	console.log("Submiting");
	threshold[0]['hitLimits'] = $("#allHit").val();
	threshold[0]['volumeCap'] = $("#allVolume").val();

	config['activationDate'] = $('#activationDate').val();
	config['terminationDate'] = $('#terminationDate').val();
	
	myJson = {}
	myJson['config'] = config;
	myJson['threshold'] = threshold;
	var id = $('#apiId').val();
	$.ajax({
	      type: "POST",
	      contentType : 'application/json',
	      dataType : 'json',
	      url: "/admin/"+id+"/saveconfig",
	      data: JSON.stringify(myJson),
	      success :function(result) {
	        console.log("success");
	     },
	     error:function(result){
	    	 console.log("done");
	     }
	  });
	$('#alerts').append('<div class=\"alert\ alert-success">' + '<button type=\"button\" class=\"close\" data-dismiss=\"alert\">' + '&times;</button>' + "Record saved successfully" + '</div>');
}
var back = function(){
	window.location.replace("/admin/apiedit");
	
}