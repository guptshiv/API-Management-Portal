package com.example.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.model.Client;
import com.example.model.ClientMaster;
import com.example.model.User;
import com.example.service.ClientService;
import com.example.service.EmailService;
import com.example.service.UserService;

@Controller
public class CheckerController {
	
		private final Logger logger = LoggerFactory.getLogger(ClientController.class);
		
		@Autowired
		private ClientService clientService;
		
		@Autowired
		private UserService userService;
		
		@Autowired 
		private EmailService emailService;
	
		@RequestMapping(value = "/checker", method = RequestMethod.GET)
		public ModelAndView showAllPendingClients() {
			ModelAndView modelAndView = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			User user = userService.findUserByEmail(auth.getName());
			modelAndView.addObject("userForm", user);
			logger.debug("showAllPendingClients()");
			List<Client> allPendingClients = clientService.findClientsByMcFlag("C");
			allPendingClients.addAll(clientService.findClientsByMcFlag("U"));
			modelAndView.addObject("clients", allPendingClients);
			List<ClientMaster> allAuthorizedClients = clientService.findAuthorizedClientsAll();
			modelAndView.addObject("aclients", allAuthorizedClients);
			List<Client> allRejectedClients = clientService.findClientsByMcFlag("R");
			modelAndView.addObject("rclients", allRejectedClients);
			modelAndView.setViewName("checker/plist");
			return modelAndView;
		}
		
		//authorize form
		@RequestMapping(value = "/checker/{id}/authorize", method = RequestMethod.GET)
		public String authorizeClient(@PathVariable("id") int id,  final RedirectAttributes redirectAttributes) {
			logger.debug("authorizeClient() : {}", id);
			Client client = clientService.findClientByID(id);
			ClientMaster clientMaster = clientService.findAuthClientByName(client.getName());
			if(clientMaster == null) {
				// new record
				if(!client.isEnabled()) {
					redirectAttributes.addFlashAttribute("css", "warning");
					redirectAttributes.addFlashAttribute("msg", "Client has not verified using email yet!");
				}
				else {
					client.setMcFlag("A");
					clientService.authorize(client);
					redirectAttributes.addFlashAttribute("css", "success");
					redirectAttributes.addFlashAttribute("msg", "Client is authorized!");
					// send confirmation mail
					//emailService.sendAuthorisationMail(client);
				}
			}
			else {
				client.setMcFlag("A");
				clientService.authorize(client);
				redirectAttributes.addFlashAttribute("css", "success");
				redirectAttributes.addFlashAttribute("msg", "Client is authorized!");
			}
			return "redirect:/checker";
		}
		
		// reject form
		@RequestMapping(value = "/checker/{id}/reject", method = RequestMethod.GET)
		public String rejectClient(@PathVariable("id") int id, final RedirectAttributes redirectAttributes) {

			logger.debug("rejectClient() : {}", id);
			Client client = clientService.findClientByID(id);
			client.setMcFlag("R");
			if(!client.isEnabled()) {
				redirectAttributes.addFlashAttribute("css", "warning");
				redirectAttributes.addFlashAttribute("msg", "Client has not verified using email yet!");
			}
			//clientService.delete(id);
			else {
				clientService.reject(client);
				redirectAttributes.addFlashAttribute("css", "success");
				redirectAttributes.addFlashAttribute("msg", "Client is rejected!");
			}
			return "redirect:/checker";

		}

		// show client
		@RequestMapping(value = "/checker/{id}", method = RequestMethod.GET)
		public String showClientDetails(@PathVariable("id") int id, Model model) {

			logger.debug("showClientDetails() id: {}", id);

			Client client = clientService.findClientByID(id);
			if (client == null) {
				model.addAttribute("css", "danger");
				model.addAttribute("msg", "client not found");
			}
			model.addAttribute("client", client);

			return "checker/view";

		}
		
}
