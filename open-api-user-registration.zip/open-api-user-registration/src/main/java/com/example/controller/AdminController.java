package com.example.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.model.ApiMaster;
import com.example.model.ApiThrottlingConfig;
import com.example.model.Client;
import com.example.model.Response;
import com.example.service.AdminService;
import com.example.service.ClientService;
import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
public class AdminController {
	
	private final Logger logger = LoggerFactory.getLogger(ClientController.class);
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private ClientService clientService;
	
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public ModelAndView showAdminHomePage() {
		logger.debug("Admin home page");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("admin/home");
		return modelAndView;
	}
	
	// view mode
	@RequestMapping(value="/admin/apiview", method= RequestMethod.GET)
	public ModelAndView apiView() {
		logger.debug("Api view page");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("admin/apiview");
		calculateModel(modelAndView);
		return modelAndView;
	}
	
	// edit mode
	@RequestMapping(value="/admin/apiedit", method= RequestMethod.GET)
	public ModelAndView apiEdit() {
		logger.debug("Api edit page");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("admin/apiedit");
		calculateModel(modelAndView);
		return modelAndView;
	}

	@RequestMapping(value="/admin/{apiId}/customer",method = RequestMethod.GET)
	public ModelAndView customerApi(@PathVariable("apiId") int apiId) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("admin/customer");
		ApiMaster selectedApi = adminService.findApiById(apiId);
		String apiname = selectedApi.getApiName();
		List<Client> clientApi = clientService.findByApi(apiname);
		modelAndView.addObject("api",selectedApi);
		modelAndView.addObject("clients",clientApi);
		return modelAndView;
	}
	
	//mapping 
	@RequestMapping(value="/admin/{id}/mapping",method=RequestMethod.GET)
	public ModelAndView showMapping(@PathVariable("id") int id) {
		ModelAndView modelAndView = new ModelAndView();
		ApiMaster selectedApi = adminService.findApiById(id);
		modelAndView.addObject("api",selectedApi);
		modelAndView.setViewName("admin/mapping");
		return modelAndView;		
	}
	
	//adduser
	@RequestMapping(value="/admin/adduser",method=RequestMethod.GET)
	public String addUser(Model model,final RedirectAttributes redirectAttributes) {
		Client client = new Client();
		if(model.containsAttribute("client")) {
			Map<String,Object> m = model.asMap();
			client = (Client)m.get("client");
		}
		client.setMcFlag("C");
		client.setUserid(0);
		model.addAttribute("client", client);
		return "admin/adduser";
	}
	@RequestMapping(value="/admin/adduser",method=RequestMethod.POST)
	public String submitAddUser(@ModelAttribute("client") @Validated Client client,
			BindingResult result, final RedirectAttributes redirectAttributes,Model model) {
		if (result.hasErrors()) {
			return "redirect:/admin/adduser";
		}
		else {
			Client c = clientService.findClientByName(client.getName());
			// Handle update of authorized
			if(c!=null && client.isNew()) {
				redirectAttributes.addFlashAttribute("css", "danger");
				redirectAttributes.addFlashAttribute("msg", "Client exists with the name: "+client.getName()+". Try some other name." );
				redirectAttributes.addFlashAttribute("client", client);
				return "redirect:/admin/adduser";
			}
			else {
					redirectAttributes.addFlashAttribute("css", "success");
					System.out.println(client.getName());
					if(client.isNew()){
						clientService.saveOrUpdate(client);
						redirectAttributes.addFlashAttribute("msg", "Client added successfully! Verification Email sent to "+ client.getEmail());
						//emailService.sendRegistrationMail(client);
						String body = "Hey "+client.getName()+"\n"+"Click here to register: "+"\n";
						String link = "localhost:8080/clients/verify"+client.getSecretKey();
						System.out.println(body+link);
					}
					else{
						clientService.saveOrUpdate(client);
						redirectAttributes.addFlashAttribute("msg", "Client updated successfully!");
					}
			}
		}
		return "redirect:/admin/adduser";
	}
	
	//setting
	@RequestMapping(value="/admin/{id}/setting",method=RequestMethod.GET)
	public ModelAndView showSetting(@PathVariable("id") int id) {
		ModelAndView modelAndView = new ModelAndView();
		ApiMaster selectedApi = adminService.findApiById(id);
		modelAndView.addObject("api",selectedApi);
		ApiThrottlingConfig config = adminService.findConfigByApiId(selectedApi.getApiId());
		if(config==null) {
			config = new ApiThrottlingConfig();
			config.setApiId(selectedApi.getApiId());
			adminService.saveOrUpdateApiConfig(config);
		}
		modelAndView.setViewName("admin/setting");
		return modelAndView;		
	}
	
	//statistics
	@RequestMapping(value="/admin/{id}/statistics",method=RequestMethod.GET)
	public ModelAndView showStatistics(@PathVariable("id") int id) {
		ModelAndView modelAndView = new ModelAndView();
		ApiMaster selectedApi = adminService.findApiById(id);
		modelAndView.addObject("api",selectedApi);
		modelAndView.setViewName("admin/statistics");
		return modelAndView;		
	}
	
	private void calculateModel(ModelAndView modelAndView) {
		List<ApiMaster> allApi = adminService.findAllApis();
		modelAndView.addObject("apis", allApi);
		Map<String,Integer> activeSubscribers = new HashMap<String, Integer>();
		for(ApiMaster api : allApi) {
			List<Client> c = clientService.findByApi(api.getApiName());
			activeSubscribers.put(api.getApiName(), c.size());
		}
		modelAndView.addObject("activeSubscribers", activeSubscribers);
		
		List<ApiMaster> active = adminService.findApisByServiceFlag('A');
		List<ApiMaster> down = adminService.findApisByServiceFlag('U');
		List<ApiMaster> blocked = adminService.findApisByServiceFlag('B');
		modelAndView.addObject("active",active.size());
		modelAndView.addObject("down",down.size());
		modelAndView.addObject("blocked",blocked.size());
		
		List<Response> responseList = adminService.findAllResponses();
		modelAndView.addObject("responseList", responseList);
		
		ObjectMapper mapper = new ObjectMapper();
		String json="";
		try {
			json = mapper.writeValueAsString(responseList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		modelAndView.addObject("list", json);
	}
	
}
