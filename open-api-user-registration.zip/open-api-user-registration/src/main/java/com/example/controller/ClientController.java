package com.example.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.model.ApiMaster;
import com.example.model.Client;
import com.example.model.ClientMaster;
import com.example.model.User;
import com.example.service.AdminService;
import com.example.service.ClientService;
import com.example.service.EmailService;
import com.example.service.UserService;

@Controller
public class ClientController {
	
	private final Logger logger = LoggerFactory.getLogger(ClientController.class);
	
	
	@Autowired
	private ClientService clientService;
	
	@Autowired
	private UserService userService;
	
	@Autowired 
	private EmailService emailService;
	
	@Autowired
	private AdminService adminService;
	
	@RequestMapping(value = "/clients", method = RequestMethod.GET)
	public ModelAndView showAllClients() {
		ModelAndView modelAndView = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		User user = userService.findUserByEmail(auth.getName());
		modelAndView.addObject("userForm", user);
		logger.debug("showAllClients()");
		int userid = user.getId();
		List<Client> pending = clientService.findClientsByUserIdAndMcFlag(userid, "C");
		pending.addAll(clientService.findClientsByUserIdAndMcFlag(userid, "U"));
 		modelAndView.addObject("clients", pending);
 		List<ClientMaster> authorized = clientService.findAuthorizedByUserid(userid);
 		List<Client> rejected = clientService.findClientsByUserIdAndMcFlag(userid, "R");
 		modelAndView.addObject("aclients", authorized);
 		modelAndView.addObject("rclients", rejected);
 		modelAndView.setViewName("clients/list");
 		return modelAndView;
	}

	// save or update client
	@RequestMapping(value = "/clients", method = RequestMethod.POST)
	public String saveOrUpdateClient(@ModelAttribute("clientForm") @Validated Client client,
			BindingResult result, Model model, final RedirectAttributes redirectAttributes) {

			logger.debug("saveOrUpdateClient() : {}", client);
			if (result.hasErrors()) {
				return "clients/clientform";
			} 
			else {
				Client c = clientService.findClientByName(client.getName());
				// Handle update of authorized
				if(c!=null && client.isNew()) {
					redirectAttributes.addFlashAttribute("css", "danger");
					redirectAttributes.addFlashAttribute("msg", "Client exists with the name: "+client.getName()+". Try some other name." );
					redirectAttributes.addFlashAttribute("clientForm", client);
					return "redirect:/clients/add";
				}
				else {
						redirectAttributes.addFlashAttribute("css", "success");
						if(client.isNew()){
							clientService.saveOrUpdate(client);
							redirectAttributes.addFlashAttribute("msg", "Client added successfully! Verification Email sent to "+ client.getEmail());
							// send verificationn mail
							//emailService.sendRegistrationMail(client);
							String body = "Hey "+client.getName()+"\n"+"Click here to register: "+"\n";
							String link = "localhost:8080/clients/verify"+client.getSecretKey();
							System.out.println(body+link);
						}
						else{
							clientService.saveOrUpdate(client);
							redirectAttributes.addFlashAttribute("msg", "Client updated successfully!");
						}
				}
				// POST/REDIRECT/GET
			return "redirect:/clients/" + client.getId();

			// POST/FORWARD/GET
			// return "client/list";
		}
	}

	// show add client form
	@RequestMapping(value = "/clients/add", method = RequestMethod.GET)
	public String showAddClientForm(Model model,final RedirectAttributes redirectAttributes) {

		logger.debug("showAddClientForm()");
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		User user = userService.findUserByEmail(auth.getName());
		Client client = new Client();
		if(model.containsAttribute("clientForm")) {
			Map<String,Object> m = model.asMap();
			client = (Client)m.get("clientForm");
		}
		client.setMcFlag("C");
		client.setUserid(user.getId());
		model.addAttribute("clientForm", client);
		populateDefaultModel(model);
		return "clients/clientform";

	}

	// show update form
	@RequestMapping(value = "/clients/{id}/update", method = RequestMethod.GET)
	public String showUpdateClientForm(@PathVariable("id") int id, Model model) {

		logger.debug("showUpdateClientForm() : {}", id);

		Client client = clientService.findClientByID(id);
		client.setMcFlag("U");
		model.addAttribute("clientForm", client);
		populateDefaultModel(model);
		return "clients/clientform";

	}
	
	// delete client
	@RequestMapping(value = "/clients/{id}/delete", method = RequestMethod.GET)
	public String deleteClient(@PathVariable("id") int id, final RedirectAttributes redirectAttributes) {

		logger.debug("deleteClient() : {}", id);
		clientService.delete(id);

		redirectAttributes.addFlashAttribute("css", "success");
		redirectAttributes.addFlashAttribute("msg", "Client is deleted!");

		return "redirect:/clients";

	}

	// show client
	@RequestMapping(value = "/clients/{id}", method = RequestMethod.GET)
	public String showClient(@PathVariable("id") int id, Model model) {

		logger.debug("showClient() id: {}", id);

		Client client = clientService.findClientByID(id);
		if (client == null) {
			model.addAttribute("css", "danger");
			model.addAttribute("msg", "client not found");
		}
		model.addAttribute("client", client);
		return "clients/show";
	}
	
	// show master record
	@RequestMapping(value = "/clients/{id}/master", method = RequestMethod.GET)
	public String showClientDetailMaster(@PathVariable("id") int id, Model model) {

		logger.debug("showClientDetails() id: {}", id);

		ClientMaster client = clientService.findAuthClientByID(id);
		if (client == null) {
				model.addAttribute("css", "danger");
				model.addAttribute("msg", "client not found");
		}
		model.addAttribute("client", client);

		return "clients/show";

	}
	
	@RequestMapping(value="/clients/verify/{clientKey}", method=RequestMethod.GET)
	public String verifyClientReg(@PathVariable("clientKey") String clientKey, Model model) {
		Client client = clientService.findClientBySecretKey(clientKey);
		System.out.println("hi"+client.getName());
		String msg = "";
		if(client!=null) {
			if(client.isEnabled()) {
				msg = "Already registered!";
				model.addAttribute("msg", msg);
				return "success";
			}
			msg="Successfully registered! Wait for authorization.";
			model.addAttribute("msg", msg);
			client.setEnabled(true);
			clientService.saveOrUpdate(client);
		}
		return "success";
	}
	
	//populate (api options)
	private void populateDefaultModel(Model model) {
		List<String> apis = new ArrayList<String>();
		List<ApiMaster> apiMasters = adminService.findAllApis();
		for(ApiMaster apiMaster : apiMasters) {
			apis.add(apiMaster.getApiName());
		}
		model.addAttribute("apis", apis);
	}
	
	@ExceptionHandler(EmptyResultDataAccessException.class)
	public ModelAndView handleEmptyData(HttpServletRequest req, Exception ex) {

		logger.debug("handleEmptyData()");
		logger.error("Request: {}, error ", req.getRequestURL(), ex);

		ModelAndView model = new ModelAndView();
		model.setViewName("client/show");
		model.addObject("msg", "client not found");

		return model;

	}

}