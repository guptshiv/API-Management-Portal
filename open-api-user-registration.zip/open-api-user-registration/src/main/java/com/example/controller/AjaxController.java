package com.example.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.ApiMaster;
import com.example.model.ApiThresholdRange;
import com.example.model.ApiThrottlingConfig;
import com.example.model.Client;
import com.example.model.Response;
import com.example.service.AdminService;
import com.example.service.ClientService;
import com.example.service.EmailService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
public class AjaxController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private ClientService clientService;
	
	@Autowired
	private EmailService emailService;
	
	//AJAX FOR TABULAR DATA IN APIEDIT
	@RequestMapping(value="/admin/apiedit/datatable", method=RequestMethod.GET)
	public ResponseEntity<?> fillTable() {
		System.out.println("hi");
		List<ApiMaster> allApi = adminService.findAllApis();
		List<Response> responseList = adminService.findAllResponses();
		Map<String,Integer> activeSubscribers = new HashMap<String, Integer>();
		for(ApiMaster api : allApi) {
			List<Client> c = clientService.findByApi(api.getApiName());
			activeSubscribers.put(api.getApiName(), c.size());
		}
		String json="";
		JSONObject obj = new JSONObject();
		ObjectMapper mapper = new ObjectMapper();
		try {
			json = mapper.writeValueAsString(allApi);
			System.out.println(json);
			obj.put("str1", json);
			json = mapper.writeValueAsString(responseList);
			System.out.println(json);
			obj.put("str2", json);
			json = mapper.writeValueAsString(activeSubscribers);
			obj.put("str3", json);
			System.out.println(obj.toString());
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(obj.toString());
	}
	
	//AJAX FOR MODAL
	@RequestMapping(value="/admin/apiedit/modalUpdate", method=RequestMethod.POST)
	public ResponseEntity<?> modalUpdate(@RequestBody String data) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			Response response = mapper.readValue(data, Response.class);
			adminService.saveOrUpdateResponses(response);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok("success");
	}
	
	//AJAX FOR API UPDATE
	@RequestMapping(value="/admin/apiedit/apiUpdate", method=RequestMethod.POST)
	public ResponseEntity<?> apiUpdate(@RequestBody String data) {
		TypeReference<List<ApiMaster>> mapType = new TypeReference<List<ApiMaster>>() {};
		ObjectMapper mapper = new ObjectMapper();
		try {
			System.out.println(data);
			List<ApiMaster> allApis = mapper.readValue(data, mapType);
			for(ApiMaster api : allApis) {
				adminService.saveOrUpdateApis(api);
			}
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok("success");
	}
	
	//AJAX FOR THROTTLING
		@RequestMapping(value="/admin/{id}/info", method=RequestMethod.GET)
		public ResponseEntity<?> throttleInfo(@PathVariable("id") int id) {
			ApiMaster selectedApi = adminService.findApiById(id);
			ApiThrottlingConfig config = adminService.findConfigByApiId(selectedApi.getApiId());
			List<ApiThresholdRange> threshold = adminService.findThresholdByConfigId(config.getConfigId());
			if(threshold.isEmpty()) {
				String weekday[] = {"ALL","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY","SUNDAY"};
				for(int i=0;i<8;++i) {
					ApiThresholdRange apiThresholdRange = new ApiThresholdRange();
					apiThresholdRange.setConfigId(config.getConfigId());
					apiThresholdRange.setWeekday(weekday[i]);
					adminService.saveOrUpdateThresholdInfo(apiThresholdRange);
				}
				threshold = adminService.findThresholdByConfigId(config.getConfigId());
			}
			String json="";
			JSONObject obj = new JSONObject();
			ObjectMapper mapper = new ObjectMapper();
			try {
				json = mapper.writeValueAsString(config);
				obj.put("config", json);
				json = mapper.writeValueAsString(threshold);
				obj.put("threshold", json);
			} catch (JsonParseException e) {
				e.printStackTrace();
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return ResponseEntity.ok(obj.toString());
		}
		
		//AJAX FOR CONFIG UPDATE
		@RequestMapping(value="/admin/{id}/saveconfig", method=RequestMethod.POST)
		public ResponseEntity<?> saveThrottleConfig(@RequestBody String data,@PathVariable("id") int id){
			System.out.println(data);
			ObjectMapper mapper = new ObjectMapper();
			TypeReference<List<ApiThresholdRange>> mapType = new TypeReference<List<ApiThresholdRange>>() {};
			try {
				JSONObject s=new JSONObject(data);
				String config = s.get("config").toString();
				ApiThrottlingConfig apiThrottlingConfig = mapper.readValue(config, ApiThrottlingConfig.class);
				adminService.saveOrUpdateApiConfig(apiThrottlingConfig);
				String threshold = s.get("threshold").toString();
				List<ApiThresholdRange> thresholdValues = mapper.readValue(threshold, mapType);
				for(ApiThresholdRange t : thresholdValues) {
					adminService.saveOrUpdateThresholdInfo(t);
				}
			} catch (JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return ResponseEntity.ok("success");
		}
		
		//AJAX FOR MAIL
		@RequestMapping(value="/admin/sendMail", method=RequestMethod.POST)
		public ResponseEntity<?> sendMailAdmin(@RequestParam(value="id")String id) {
			int clientId = Integer.parseInt(id);
			Client c = clientService.findClientByID(clientId);
			System.out.println(c.getName());
			//emailService.sendRegistrationMail(c);
			return ResponseEntity.ok("success");
		}
		
		//AJAX FOR TABULAR DATA IN CUSTOMER MAPPING
		@RequestMapping(value="/admin/{apiId}/maphelp", method=RequestMethod.GET)
		public ResponseEntity<?> mappingHelper(@PathVariable("apiId") String apiId) {
			int id = Integer.parseInt(apiId);
			System.out.println(id);
			ApiMaster selectedApi = adminService.findApiById(id);
			String apiname = selectedApi.getApiName();
			List<Client> clientApi = clientService.findByApi(apiname);
			
			List<Client> allClients = clientService.findAll();
			for(Client c : clientApi) {
				if(allClients.contains(c)) {
					allClients.remove(c);
				}
			}
			String json="";
			JSONObject obj = new JSONObject();
			ObjectMapper mapper = new ObjectMapper();
			try {
				json = mapper.writeValueAsString(allClients);
				System.out.println(json);
				obj.put("str1", json);
				json = mapper.writeValueAsString(clientApi);
				System.out.println(json);
				obj.put("str2", json);
				System.out.println(obj.toString());
			} catch (JsonParseException e) {
				e.printStackTrace();
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return ResponseEntity.ok(obj.toString());
		}
		
		//AJAX FOR OPERATION IN CUSTOMER MAPPING
		@RequestMapping(value="/admin/{apiId}/mapsave/{clientId}", method=RequestMethod.GET)
		public ResponseEntity<?> mappingSaver(@PathVariable("apiId") String apiId,@PathVariable("clientId") String clientId) {
			int apiid = Integer.parseInt(apiId);
			int clientid = Integer.parseInt(clientId);
			System.out.println(apiid+","+clientid);
			ApiMaster selectedApi = adminService.findApiById(apiid);
			String apiname = selectedApi.getApiName();
			Client client = clientService.findClientByID(clientid);
			String apiC = client.getApiSelection();
			apiC+=","+apiname;
			client.setApiSelection(apiC);
			clientService.saveOrUpdate(client);
			List<Client> clientApi = clientService.findByApi(apiname);
			
			List<Client> allClients = clientService.findAll();
			for(Client c : clientApi) {
				if(allClients.contains(c)) {
					allClients.remove(c);
				}
			}
			String json="";
			JSONObject obj = new JSONObject();
			ObjectMapper mapper = new ObjectMapper();
			try {
				json = mapper.writeValueAsString(allClients);
				System.out.println(json);
				obj.put("str1", json);
				json = mapper.writeValueAsString(clientApi);
				System.out.println(json);
				obj.put("str2", json);
				System.out.println(obj.toString());
			} catch (JsonParseException e) {
				e.printStackTrace();
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return ResponseEntity.ok(obj.toString());
		}
}
