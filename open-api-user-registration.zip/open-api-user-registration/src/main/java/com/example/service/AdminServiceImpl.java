package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.ApiMaster;
import com.example.model.ApiThresholdRange;
import com.example.model.ApiThrottlingConfig;
import com.example.model.Response;
import com.example.repository.ApiMasterRepository;
import com.example.repository.ApiThresholdRepository;
import com.example.repository.ApiThrottlingConfigRepository;
import com.example.repository.ResponseRepository;

@Service("adminService")
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	private ApiMasterRepository apiMasterRepository;
	
	@Autowired
	private ResponseRepository responseRepository;
	
	@Autowired
	private ApiThrottlingConfigRepository apiThrottlingConfigRepository;
	
	@Autowired
	private ApiThresholdRepository apiThresholdRespository;

	@Override
	public List<ApiMaster> findAllApis() {
		return apiMasterRepository.findAll();
	}
	
	@Override
	public ApiMaster findApiById(int id) {
		return apiMasterRepository.findByApiId(id);
	}
	
	@Override
	public List<ApiMaster> findApisByServiceFlag(char serviceStatus) {
		return apiMasterRepository.findByServiceStatus(serviceStatus);
	}

	@Override
	public void saveOrUpdateApis(ApiMaster apiMaster) {
		apiMasterRepository.save(apiMaster);
	}

	@Override
	public List<Response> findAllResponses() {
		return responseRepository.findAll();
	}

	@Override
	public void saveOrUpdateResponses(Response response) {
		responseRepository.save(response);
		
	}

	@Override
	public ApiThrottlingConfig findConfigByApiId(int apiId) {
		return apiThrottlingConfigRepository.findByApiId(apiId);
	}

	@Override
	public ApiThrottlingConfig findConfigByConfigId(int configId) {
		return apiThrottlingConfigRepository.findByConfigId(configId);
	}

	@Override
	public void saveOrUpdateApiConfig(ApiThrottlingConfig config) {
		apiThrottlingConfigRepository.save(config);
		
	}

	@Override
	public List<ApiThresholdRange> findThresholdByConfigId(int configId) {
		return apiThresholdRespository.findByConfigId(configId);
	}

	@Override
	public void saveOrUpdateThresholdInfo(ApiThresholdRange apiThresholdRange) {
		apiThresholdRespository.save(apiThresholdRange);
		
	}
	
}
