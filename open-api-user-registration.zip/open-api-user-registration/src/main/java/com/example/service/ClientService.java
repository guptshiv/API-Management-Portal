package com.example.service;

import java.util.List;

import com.example.model.Client;
import com.example.model.ClientHistory;
import com.example.model.ClientMaster;

public interface ClientService {
	
	Client findClientByID(Integer id);
	ClientMaster findAuthClientByID(Integer id);
	ClientMaster findAuthClientByName(String name);
	List<Client> findAll();

	List<Client> findByApi(String api);
	List<Client> findClientsByUserId(int userid);
	List<Client> findClientsByMcFlag(String mcFlag);
	Client findClientByName(String name);
	Client findClientBySecretKey(String secretKey);
	List<Client> findClientsByUserIdAndMcFlag(int userid, String mcFlag);
	
	List<ClientMaster> findAuthorizedClientsAll();
	List<ClientMaster> findAuthorizedByUserid(int userid);
	
	void delete(Integer id);
	void saveOrUpdate(Client client);
	void authorize(Client client);
	void reject(Client client);
	
	ClientHistory toClientHistory(Client client);
	ClientMaster toClientMaster(Client client);
	Client toClientFromCM(ClientMaster clientMaster);
	//Client toClientFromCH(ClientHistory clientHistory);
}