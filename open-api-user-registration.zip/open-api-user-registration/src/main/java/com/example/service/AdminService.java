package com.example.service;

import java.util.List;

import com.example.model.ApiMaster;
import com.example.model.ApiThresholdRange;
import com.example.model.ApiThrottlingConfig;
import com.example.model.Response;

public interface AdminService {
	
	List<ApiMaster> findAllApis();
	List<ApiMaster> findApisByServiceFlag(char serviceStatus);
	ApiMaster findApiById(int id);
	void saveOrUpdateApis(ApiMaster apiMaster);
	
	ApiThrottlingConfig findConfigByApiId(int apiId);
	ApiThrottlingConfig findConfigByConfigId(int configId);
	void saveOrUpdateApiConfig(ApiThrottlingConfig config);
	
	List<ApiThresholdRange> findThresholdByConfigId(int configId);
	void saveOrUpdateThresholdInfo(ApiThresholdRange apiThresholdRange);
	
	List<Response> findAllResponses();
	void saveOrUpdateResponses(Response response);
}
