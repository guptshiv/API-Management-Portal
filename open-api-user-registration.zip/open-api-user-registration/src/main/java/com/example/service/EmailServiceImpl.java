package com.example.service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.example.model.Client;

@Service("emailService")
public class EmailServiceImpl implements EmailService{

	@Autowired
	private JavaMailSender sender;

	@Override
	public void sendRegistrationMail(Client client) {
		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom("");
			helper.setTo(client.getEmail());
			helper.setSubject("Registration Mail");
			String body = "Hey "+client.getName()+"\n"+"Click here to register: "+"\n";
			String link = "localhost:8080/clients/verify"+client.getSecretKey();
			helper.setText(body+link);
			System.out.println(body+link);
			
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		sender.send(message);
	}

	@Override
	public void sendAuthorisationMail(Client client) {
		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom("");
			helper.setTo(client.getEmail());
			helper.setSubject("Credentials Mail");
			String body = "Hello "+client.getName()+",\n"+"Client Id: "+client.getName()+"\n Secret Key: "+client.getSecretKey()+"\n";
			System.out.println(body);
			helper.setText(body);
			
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		sender.send(message);
	}

	
	
	
}
