package com.example.service;

import com.example.model.Client;

public interface EmailService {
	public void sendRegistrationMail(Client client);
	public void sendAuthorisationMail(Client client);
}
