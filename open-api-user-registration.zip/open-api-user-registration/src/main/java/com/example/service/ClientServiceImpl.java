package com.example.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.model.Client;
import com.example.model.ClientHistory;
import com.example.model.ClientMaster;
import com.example.repository.ClientHistoryRepository;
import com.example.repository.ClientMasterRepository;
import com.example.repository.ClientRepository;

@Transactional
@Service("clientService")
public class ClientServiceImpl implements ClientService{
	
	@Autowired
	private ClientRepository clientRepository;
	
	@Autowired 
	private ClientHistoryRepository clientHistoryRepository;
	
	@Autowired
	private ClientMasterRepository clientMasterRepository;
	
	private String generateSecretKey(String clientName) {
		String password = clientName;
		MessageDigest md;
		try {
			md = MessageDigest.getInstance("SHA-256");
			md.update(password.getBytes());
			byte byteData[] = md.digest();
	        //convert the byte to hex format method
	        StringBuffer sb = new StringBuffer();
	        for (int i = 0; i < byteData.length; i++) {
	         sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
	        }
	        password = sb.toString();
			} catch (NoSuchAlgorithmException e) {
			System.out.println("Error in generating hash password");
			e.printStackTrace();
		}
		return password;
	}
	
	/*@Override
	public void saveUser(Client client) {
		client.setSecretKey(generateSecretKey(client.getName()));
		clientRepository.save(client);
	}*/

	@Override
	public Client findClientByID(Integer id) {
		return clientRepository.findById(id);
	}

	@Override
	public List<Client> findAll() {
		return clientRepository.findAll();
	}

	@Override
	public void saveOrUpdate(Client client) {
		//Client client = clientRepository.findByID(id);
		//client.setPassword(bCryptPasswordEncoder.encode(client.getPassword()));
		client.setSecretKey(generateSecretKey(client.getName()));
		System.out.println("user id will be "+ client.getUserid());
		System.out.println("Hey my secret key "+client.getSecretKey());
		clientRepository.save(client);
	}

	@Override
	@Transactional
	public void delete(Integer id) {
		Client client = clientRepository.findById(id);
		client.setMcFlag("D");
		saveOrUpdate(client);
		//clientRepository.deleteById(id);
	}

	@Override
	public List<Client> findClientsByUserId(int userid) {
		return clientRepository.findByUserid(userid);
	}

	@Override
	public Client findClientByName(String name) {
		return clientRepository.findByName(name);
	}

	@Override
	public List<Client> findClientsByMcFlag(String mcFlag) {
		return clientRepository.findByMcFlag(mcFlag);
	}
	@Override
	public List<Client> findClientsByUserIdAndMcFlag(int userid, String mcFlag) {
		return clientRepository.findByUseridAndMcFlag(userid, mcFlag);
	}

	@Override
	public void authorize(Client client) {
		client.setMcFlag("A");
		saveOrUpdate(client);
		ClientMaster mas = clientMasterRepository.findByName(client.getName());
		if(mas!=null) {
			Client tmp = toClientFromCM(mas);
			ClientHistory his = toClientHistory(tmp);
			clientHistoryRepository.save(his);
			System.out.println("saved successfully");
			clientMasterRepository.deleteById(mas.getId());
			System.out.println("deleted successfully");
		}
		mas = toClientMaster(client);
		clientMasterRepository.save(mas);
		System.out.println("here");
	}

	@Override
	public void reject(Client client) {
		client.setMcFlag("R");
		saveOrUpdate(client);
		
	}

	@Override
	public ClientHistory toClientHistory(Client client) {
		ClientHistory clientHistory = new ClientHistory();
		clientHistory.setName(client.getName());
		clientHistory.setEmail(client.getEmail());
		clientHistory.setPref(client.getPref());
		clientHistory.setFromDate(client.getFromDate());
		clientHistory.setTillDate(client.getTillDate());
		clientHistory.setSecretKey(client.getSecretKey());
		clientHistory.setApiSelection(client.getApiSelection());
		clientHistory.setBurstCount(client.getBurstCount());
		clientHistory.setConcurrentUsers(client.getConcurrentUsers());
		clientHistory.setTimePeriod(client.getTimePeriod());
		clientHistory.setConcurrentHits(client.getConcurrentHits());
		clientHistory.setWhitelistIP(client.getWhitelistIP());
		clientHistory.setMacAddress(client.getMacAddress());
		clientHistory.setRoles(client.getRoles());
		clientHistory.setMcFlag(client.getMcFlag());
		clientHistory.setUserid(client.getUserid());
		return clientHistory;
	}

	@Override
	public ClientMaster toClientMaster(Client client) {
		ClientMaster clientMaster = new ClientMaster();
		clientMaster.setId(client.getId());
		clientMaster.setName(client.getName());
		clientMaster.setEmail(client.getEmail());
		clientMaster.setPref(client.getPref());
		clientMaster.setFromDate(client.getFromDate());
		clientMaster.setTillDate(client.getTillDate());
		clientMaster.setSecretKey(client.getSecretKey());
		clientMaster.setApiSelection(client.getApiSelection());
		clientMaster.setBurstCount(client.getBurstCount());
		clientMaster.setConcurrentUsers(client.getConcurrentUsers());
		clientMaster.setTimePeriod(client.getTimePeriod());
		clientMaster.setConcurrentHits(client.getConcurrentHits());
		clientMaster.setWhitelistIP(client.getWhitelistIP());
		clientMaster.setMacAddress(client.getMacAddress());
		clientMaster.setRoles(client.getRoles());
		clientMaster.setMcFlag(client.getMcFlag());
		clientMaster.setUserid(client.getUserid());
		return clientMaster;
	}

	@Override
	public Client toClientFromCM(ClientMaster clientMaster) {
		Client client = new Client();
		client.setId(clientMaster.getId());
		client.setName(clientMaster.getName());
		client.setEmail(clientMaster.getEmail());
		client.setPref(clientMaster.getPref());
		client.setFromDate(clientMaster.getFromDate());
		client.setTillDate(clientMaster.getTillDate());
		client.setSecretKey(clientMaster.getSecretKey());
		client.setApiSelection(clientMaster.getApiSelection());
		client.setBurstCount(clientMaster.getBurstCount());
		client.setConcurrentUsers(clientMaster.getConcurrentUsers());
		client.setTimePeriod(clientMaster.getTimePeriod());
		client.setConcurrentHits(clientMaster.getConcurrentHits());
		client.setWhitelistIP(clientMaster.getWhitelistIP());
		client.setMacAddress(clientMaster.getMacAddress());
		client.setRoles(clientMaster.getRoles());
		client.setMcFlag(clientMaster.getMcFlag());
		client.setUserid(clientMaster.getUserid());
		return client;
	}

	@Override
	public List<ClientMaster> findAuthorizedClientsAll() {
		return clientMasterRepository.findAll();
	}

	@Override
	public List<ClientMaster> findAuthorizedByUserid(int userid) {
		return clientMasterRepository.findByUserid(userid);
	}

	@Override
	public ClientMaster findAuthClientByID(Integer id) {
		return clientMasterRepository.findById(id);
	}

	@Override
	public Client findClientBySecretKey(String secretKey) {
		return clientRepository.findBySecretKey(secretKey);
	}

	@Override
	public ClientMaster findAuthClientByName(String name) {
		return clientMasterRepository.findByName(name);
	}

	@Override
	public List<Client> findByApi(String api) {
		return clientRepository.findByApiSelectionIgnoreCaseContaining(api);
	}


}