package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.model.ClientHistory;

@Repository("clientHistoryRepository")
public interface ClientHistoryRepository  extends JpaRepository<ClientHistory, Long>{
	ClientHistory findById(Integer id);
	List<ClientHistory> findAll();
	List<ClientHistory> findByUserid(int userid);
	List<ClientHistory> findByMcFlag(String mcFlag);
	Long deleteById(Integer id);
	ClientHistory findByName(String name);
	List<ClientHistory> findByUseridAndMcFlag(int userid, String mcFlag);
}