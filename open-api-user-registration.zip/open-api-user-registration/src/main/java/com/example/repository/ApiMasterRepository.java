package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.model.ApiMaster;

@Repository("apiMasterRepository")
public interface ApiMasterRepository extends JpaRepository<ApiMaster, Long>{
	List<ApiMaster> findAll();
	List<ApiMaster> findByServiceStatus(char serviceStatus);
	ApiMaster findByApiId(int id);
}
