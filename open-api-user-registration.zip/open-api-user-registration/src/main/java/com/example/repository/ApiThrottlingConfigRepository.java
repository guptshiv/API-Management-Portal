package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.model.ApiThrottlingConfig;

@Repository("apiThrottlingConfigRepository")
public interface ApiThrottlingConfigRepository extends JpaRepository<ApiThrottlingConfig, Long>{
	
	List<ApiThrottlingConfig> findAll();
	ApiThrottlingConfig findByApiId(int apiId);
	ApiThrottlingConfig findByConfigId(int configId);
	
}
