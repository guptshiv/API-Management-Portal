package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.model.Client;

@Repository("clientRepository")
public interface ClientRepository  extends JpaRepository<Client, Long>{
	Client findById(Integer id);
	Client findBySecretKey(String secretKey);
	List<Client> findAll();
	List<Client> findByUserid(int userid);
	List<Client> findByMcFlag(String mcFlag);
	Long deleteById(Integer id);
	Client findByName(String name);
	List<Client> findByUseridAndMcFlag(int userid, String mcFlag);
	List<Client> findByApiSelectionIgnoreCaseContaining(String api);
}