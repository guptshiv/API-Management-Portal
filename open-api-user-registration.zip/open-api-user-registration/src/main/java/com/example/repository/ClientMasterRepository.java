package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.model.ClientMaster;

@Repository("clientMasterRepository")
public interface ClientMasterRepository  extends JpaRepository<ClientMaster, Long>{
	ClientMaster findById(Integer id);
	List<ClientMaster> findAll();
	List<ClientMaster> findByUserid(int userid);
	List<ClientMaster> findByMcFlag(String mcFlag);
	Long deleteById(Integer id);
	String deleteByName(String name);
	ClientMaster findByName(String name);
	List<ClientMaster> findByUseridAndMcFlag(int userid, String mcFlag);
}