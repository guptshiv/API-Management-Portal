package com.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "clients")
public class Client {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Integer id;
	
	@NotEmpty(message = "*Please provide a client username")
	@Column(name = "name")
	private String name;
	
	@Column(name = "email")
	@Email(message = "*Please provide a valid Email")
	@NotEmpty(message = "*Please provide an email")
	private String email;
	
	@Column(name="from_date")
	private String fromDate;
	
	@Column(name="till_date")
	private String tillDate;

	@Column(name="pref")
	private int pref;
	
	@Column(name="secretkey")
	private String secretKey;
	
	
	@Column(name="api_selection")
	private String apiSelection;
	
	@Column(name="concurrent_users")
	private int concurrentUsers;
	
	@Column(name="time_period")
	private int timePeriod;
	
	@Column(name="concurrent_hits")
	private int concurrentHits;
	
	@Column(name="whitelist_ip")
	private String whitelistIP;
	
	@Column(name="mac_address")
	private String macAddress;
	
	@Column(name="roles")
	private String roles;
	
	@Column(name="user_id")
	private int userid;
	
	@Column(name="mc_flag")
	private String mcFlag;
	
	@Column(name="enabled")
	private boolean enabled;
	
	@Column(name="burst_count")
	private int burstCount;
	
	public int getBurstCount() {
		return burstCount;
	}

	public void setBurstCount(int burstCount) {
		this.burstCount = burstCount;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public Client() {
		this.secretKey = "**********";
		this.enabled=false;
	}
	
	public boolean isNew() {
		return (this.mcFlag.equals("C"));
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
	
	

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getTillDate() {
		return tillDate;
	}

	public void setTillDate(String tillDate) {
		this.tillDate = tillDate;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public String getApiSelection() {
		return apiSelection;
	}

	public void setApiSelection(String apiSelection) {
		this.apiSelection = apiSelection;
	}

	public int getConcurrentUsers() {
		return concurrentUsers;
	}

	public void setConcurrentUsers(int concurrentUsers) {
		this.concurrentUsers = concurrentUsers;
	}

	public String getMcFlag() {
		return mcFlag;
	}

	public void setMcFlag(String mcFlag) {
		this.mcFlag = mcFlag;
	}
	public int getPref() {
		return pref;
	}

	public void setPref(int pref) {
		this.pref = pref;
	}

	public int getTimePeriod() {
		return timePeriod;
	}

	public void setTimePeriod(int timePeriod) {
		this.timePeriod = timePeriod;
	}

	public int getConcurrentHits() {
		return concurrentHits;
	}

	public void setConcurrentHits(int concurrentHits) {
		this.concurrentHits = concurrentHits;
	}

	public String getWhitelistIP() {
		return whitelistIP;
	}

	public void setWhitelistIP(String whitelistIP) {
		this.whitelistIP = whitelistIP;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
}