package com.example.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "api_Master")
public class ApiMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "api_id")
	private int apiId;
	
	@Column(name = "activation_flag")
	private char activationFlag;
	
	@Column(name = "api_code")
	private String apiCode;
	
	@Column(name = "api_name")
	private String apiName;
	
	@Column(name = "module_name")
	private String moduleName;
	
	@Column(name = "endpoint_url")
	private String endpointUrl;
	
	@Column(name = "service_status")
	private char serviceStatus;
	
	@Column(name = "active_time", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date activeTime;
	
	@Column(name = "down_time", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date downTime;
	
	public int getApiId() {
		return apiId;
	}

	public void setApiId(int apiId) {
		this.apiId = apiId;
	}

	public char getActivationFlag() {
		return activationFlag;
	}

	public void setActivationFlag(char activationFlag) {
		this.activationFlag = activationFlag;
	}

	public String getApiCode() {
		return apiCode;
	}

	public void setApiCode(String apiCode) {
		this.apiCode = apiCode;
	}

	public String getApiName() {
		return apiName;
	}

	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getEndpointUrl() {
		return endpointUrl;
	}

	public void setEndpointUrl(String endpointUrl) {
		this.endpointUrl = endpointUrl;
	}

	public char getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(char serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	public Date getActiveTime() {
		return activeTime;
	}

	public void setActiveTime(Date activeTime) {
		this.activeTime = activeTime;
	}

	public Date getDownTime() {
		return downTime;
	}

	public void setDownTime(Date downTime) {
		this.downTime = downTime;
	}
	
	
}
