package com.example.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="API_THRESHOLD_RANGE")
public class ApiThresholdRange {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "threshold_id")
	private int thresholdId;
	
	@Column(name = "config_id")
	private int configId;
	
	@Column(name="weekday")
	private String weekday;
	
	/*@Column(name = "from_time", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIME)
	private Date fromTime;
	
	@Column(name = "to_time", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIME)
	private Date toTime;*/
	@Column(name="from_time")
	private String fromTime;
	
	@Column(name="to_time")
	private String toTime;
	
	@Column(name = "hit_limits")
	private int hitLimits;
	
	@Column(name = "volume_cap")
	private double volumeCap;

	public int getThresholdId() {
		return thresholdId;
	}

	public void setThresholdId(int thresholdId) {
		this.thresholdId = thresholdId;
	}

	public int getConfigId() {
		return configId;
	}

	public void setConfigId(int configId) {
		this.configId = configId;
	}

	public String getWeekday() {
		return weekday;
	}

	public void setWeekday(String weekday) {
		this.weekday = weekday;
	}

	public String getFromTime() {
		return fromTime;
	}

	public void setFromTime(String fromTime) {
		this.fromTime = fromTime;
	}

	public String getToTime() {
		return toTime;
	}

	public void setToTime(String toTime) {
		this.toTime = toTime;
	}

	public int getHitLimits() {
		return hitLimits;
	}

	public void setHitLimits(int hitLimits) {
		this.hitLimits = hitLimits;
	}

	public double getVolumeCap() {
		return volumeCap;
	}

	public void setVolumeCap(double volumeCap) {
		this.volumeCap = volumeCap;
	}
	
	
}
