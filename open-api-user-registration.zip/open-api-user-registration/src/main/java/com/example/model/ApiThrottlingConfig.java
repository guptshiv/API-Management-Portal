package com.example.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "api_throttling_config")
public class ApiThrottlingConfig {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "config_id")
	private int configId;
	
	@Column(name = "api_id")
	private int apiId;
	
	/*@Column(name = "activation_date", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date activationDate;
	
	@Column(name = "termination_date", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date terminationDate;*/
	@Column(name = "activation_date")
	private String activationDate;
	
	@Column(name = "termination_date")
	private String terminationDate;
	
	@Column(name="limit_type")
	private int limitType;
	
	@Column(name="threshold_type")
	private int thresholdType;
	
	@Column(name="on_breach")
	private int onBreach;
	
	/*@Id
	@AttributeOverrides({
		@AttributeOverride(name="api_id",column = @Column(name="api_id")),
		@AttributeOverride(name="config_id",column = @Column(name="config_id"))
	})*/

	public int getApiId() {
		return apiId;
	}

	public void setApiId(int apiId) {
		this.apiId = apiId;
	}

	public int getConfigId() {
		return configId;
	}

	public void setConfigId(int configId) {
		this.configId = configId;
	}

	public String getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}

	public String getTerminationDate() {
		return terminationDate;
	}

	public void setTerminationDate(String terminationDate) {
		this.terminationDate = terminationDate;
	}

	public int getLimitType() {
		return limitType;
	}

	public void setLimitType(int limitType) {
		this.limitType = limitType;
	}

	public int getThresholdType() {
		return thresholdType;
	}

	public void setThresholdType(int thresholdType) {
		this.thresholdType = thresholdType;
	}

	public int getOnBreach() {
		return onBreach;
	}

	public void setOnBreach(int onBreach) {
		this.onBreach = onBreach;
	}
	
}
